//
//  RecipeAppApp.swift
//  RecipeApp
//
//  Created by Jonathan Tri Christianto on 03/06/22.
//

import SwiftUI

@main
struct RecipeAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
