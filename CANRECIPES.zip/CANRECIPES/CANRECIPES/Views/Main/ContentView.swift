//
//  ContentView.swift
//  RecipeApp
//
//  Created by Jonathan Tri Christianto on 03/06/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
       TabBar()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
