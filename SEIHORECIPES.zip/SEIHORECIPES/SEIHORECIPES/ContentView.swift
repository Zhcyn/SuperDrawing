//
//  ContentView.swift
//  Seiho
//
//  Created by Leon Lux on 12.06.22.
//

import SwiftUI

struct ContentView: View {
    
    @StateObject var router = SeihoTabViewRouter()
    
    var body: some View {
        SeihoTabView(viewRouter: router)
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
