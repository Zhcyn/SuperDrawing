//
//  IngredientListView.swift
//  Seiho
//
//  Created by Leon Lux on 16.06.22.
//

import SwiftUI

struct IngredientListElement: Identifiable {
    var id = UUID()
    var name: String
    var amount: Int
    var unit: MeasurementType
}

extension IngredientListElement {
    static let samples = [
        IngredientListElement(name: "Flour", amount: 10, unit: .gram),
        IngredientListElement(name: "Water", amount: 100, unit: .litre),
        IngredientListElement(name: "Yeast", amount: 4, unit: .gram)
    ]
}

struct IngredientListView: View {
    var body: some View {
        List {
            ForEach(IngredientListElement.samples, id: \.self.id) { element in
                HStack {
                    Text("\(element.name)")
                    Spacer()
                    Text("\(element.amount)")
                }
            }
        }
    }
}

struct IngredientListView_Previews: PreviewProvider {
    static var previews: some View {
        IngredientListView()
    }
}
