//
//  Recipe.swift
//  Seiho
//
//  Created by Leon Lux on 12.06.22.
//

import Foundation

struct Recipe {
    var title: String
    
}
