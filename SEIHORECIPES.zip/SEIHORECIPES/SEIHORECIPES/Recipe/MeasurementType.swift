//
//  MeasurementType.swift
//  Seiho
//
//  Created by Leon Lux on 14.06.22.
//

import Foundation

//TODO: Implement displaying ingredients with proper localized units

enum MeasurementType: Int32 {
    case gram = 0
    case tablespoon = 1
    case teaspoon = 2
    case litre = 3
}

extension Ingredient {
    var measurementType: MeasurementType {
        get {
            return MeasurementType(rawValue: self.unit)!
        }
        set {
            self.unit = newValue.rawValue
        }
    }
}
