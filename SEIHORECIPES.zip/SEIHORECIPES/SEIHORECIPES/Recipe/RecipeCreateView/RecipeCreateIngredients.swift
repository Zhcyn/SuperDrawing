//
//  RecipeCreateIngredients.swift
//  Seiho
//
//  Created by Leon Lux on 16.06.22.
//

import SwiftUI

struct RecipeCreateIngredients: View {
    
    @Binding var ingredientsList: [Ingredient]
    
    var body: some View {
        VStack {
            
            List {
                ForEach(ingredientsList) { ingredient in
                    HStack {
                        Text("\(ingredient.name ?? "unkown")")
                        Spacer()
                        Text("\(ingredient.amount)")
                        Text("Placeholder")
                    }
                }
            }
            //TODO: Fix weird box around button
            Button("Add Ingredient") {}
                .buttonStyle(.bordered)
                .tint(.purple)
        }
    }
}

struct RecipeCreateIngredients_Previews: PreviewProvider {
    
    @State static var ingredientList: [Ingredient] = []
    
    static var previews: some View {
        RecipeCreateIngredients(ingredientsList: $ingredientList)
    }
}
