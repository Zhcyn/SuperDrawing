//
//  RecipeCreateViewRouter.swift
//  Seiho
//
//  Created by Leon Lux on 16.06.22.
//

import Foundation

enum RecipeCreatePage: Hashable {
    case overview
    case ingredients
    case steps
    case pictures
}
