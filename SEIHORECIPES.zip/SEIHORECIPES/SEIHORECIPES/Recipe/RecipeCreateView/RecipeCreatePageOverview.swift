//
//  RecipeCreatePageOverview.swift
//  Seiho
//
//  Created by Leon Lux on 16.06.22.
//

import SwiftUI

struct RecipeCreatePageOverview: View {
    
    @Binding var recipeName: String
    
    var body: some View {
        Form {
            Section {
                TextField("Recipe Name", text: $recipeName)
            }
            
            Section {
                Button("Save Changes") {
                    
                }
            }
        }
    }
}

struct RecipeCreatePageOverview_Previews: PreviewProvider {
    
    @State static var recipeName: String = ""
    
    static var previews: some View {
        RecipeCreatePageOverview(recipeName: $recipeName)
    }
}
