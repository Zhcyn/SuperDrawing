//
//  RecipeCreateView.swift
//  Seiho
//
//  Created by Leon Lux on 14.06.22.
//

import SwiftUI
import CoreData

struct RecipeCreateView: View {
    
    @Environment(\.managedObjectContext) var moc
    @State private var currentPage: RecipeCreatePage = .overview
    @State private var recipeName: String = ""
    @State private var ingredientList: [Ingredient] = []
    
    var body: some View {
        NavigationView {
            VStack {
                Picker("Page", selection: $currentPage) {
                    Text("Overview").tag(RecipeCreatePage.overview)
                    Text("Ingredients").tag(RecipeCreatePage.ingredients)
                    Text("Steps").tag(RecipeCreatePage.steps)
                    Text("Pictures").tag(RecipeCreatePage.pictures)
                }.pickerStyle(SegmentedPickerStyle())
                    .padding(EdgeInsets(top: 0, leading: 5, bottom: 0, trailing: 5))
                    .navigationTitle("New Recipe")
                switch currentPage {
                case .overview:
                    RecipeCreatePageOverview(recipeName: $recipeName)
                case .ingredients:
                    RecipeCreateIngredients(ingredientsList: $ingredientList)
                case .steps:
                    Text("Steps")
                case .pictures:
                    Text("Pictures")
                }
            }
        }.navigationViewStyle(StackNavigationViewStyle())
    }
}

struct RecipeCreateView_Previews: PreviewProvider {
    static var previews: some View {
        
        RecipeCreateView()
    }
}

