//
//  RecipeGalleryView.swift
//  Seiho
//
//  Created by Leon Lux on 12.06.22.
//

import Foundation
import SwiftUI
import CoreData


struct RecipeGalleryView: View {
    
    @Environment(\.managedObjectContext) var moc
    
    @FetchRequest(sortDescriptors: []) var recipes: FetchedResults<Recipe>
    
    private var twoColumnGrid = [GridItem(.flexible()), GridItem(.flexible())]
    
    var body: some View {
        NavigationView {
            ScrollView {
                
                LazyVGrid(columns: twoColumnGrid) {
                    ForEach(recipes, id: \.id) { recipe in
                        RecipeView(recipe: recipe)
                    }
                }
            }.navigationTitle("Recipes")
        }.navigationViewStyle(StackNavigationViewStyle())
    }
}

struct RecipeGalleryView_Previews: PreviewProvider {
    static var previews: some View {
        RecipeGalleryView()
    }
}
