//
//  RecipeView.swift
//  Seiho
//
//  Created by Leon Lux on 12.06.22.
//

import SwiftUI

struct RecipeView: View {
    
    var recipe: Recipe
    
    init(recipe: Recipe) {
        self.recipe = recipe
    }
    
    var body: some View {
        ZStack {
            RoundedRectangle(cornerRadius: 15, style: .continuous)
                .fill(.white)
            VStack {
                Text(recipe.name ?? "unknown")
                    .font(.title)
                    .foregroundColor(.black)
            }
            .padding(20)
            .multilineTextAlignment(.center)
        }
    }
}
