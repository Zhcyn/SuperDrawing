//
//  SeihoApp.swift
//  Seiho
//
//  Created by Leon Lux on 12.06.22.
//

import SwiftUI

@main
struct SeihoApp: App {
    
    @StateObject private var dataController = DataController()
    
    var body: some Scene {
        WindowGroup {
            ContentView()
                .environment(\.managedObjectContext, dataController.container.viewContext)
        }
    }
}
