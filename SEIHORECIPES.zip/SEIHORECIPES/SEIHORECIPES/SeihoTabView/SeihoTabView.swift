//
//  SeihoTabView.swift
//  Seiho
//
//  Created by Leon Lux on 13.06.22.
//

import SwiftUI

struct SeihoTabView: View {
    
    @StateObject var viewRouter: SeihoTabViewRouter
    @State var showPopUp: Bool = false
    
    
    var body: some View {
        GeometryReader { geometry in
            VStack {
                Spacer()
                switch viewRouter.currentPage {
                case .recipes:
                    RecipeGalleryView()
                case .search:
                    SearchView()
                    //TODO: Correct when views are finished
                case .liked:
                    Text("Liked")
                case .list:
                    Text("List")
                }
                Spacer()
                ZStack {
                    HStack {
                        SeihoTabViewIcon(width: geometry.size.width, height: geometry.size.height, systemIconName: "fork.knife.circle", tabName: "Recipes", viewRouter: viewRouter, assignedPage: .recipes)
                        SeihoTabViewIcon(width: geometry.size.width, height: geometry.size.height, systemIconName: "magnifyingglass", tabName: "Search", viewRouter: viewRouter, assignedPage: .search)
                        ZStack {
                            Circle()
                                .foregroundColor(.white)
                                .frame(width: geometry.size.width / 7, height: geometry.size.height / 7)
                                .shadow(radius: 4)
                            Image(systemName: "plus.circle.fill")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: geometry.size.width / 7-5, height: geometry.size.height / 7-5)
                                .foregroundColor(Color(.purple))
                        }.offset(y: -geometry.size.height / 8 / 2)
                            .onTapGesture {
                                showPopUp.toggle()
                            }
                        SeihoTabViewIcon(width: geometry.size.width, height: geometry.size.height, systemIconName: "heart", tabName: "Liked", viewRouter: viewRouter, assignedPage: .liked)
                        SeihoTabViewIcon(width: geometry.size.width, height: geometry.size.height, systemIconName: "list.dash", tabName: "List", viewRouter: viewRouter, assignedPage: .list)
                    }.sheet(isPresented: $showPopUp) {
                        RecipeCreateView()
                    }
                    .frame(width: geometry.size.width, height: geometry.size.height / 8)
                    .background(Color(.black).shadow(radius: 2))
                    
                }
            }.edgesIgnoringSafeArea(.bottom)
            
        }
    }
}

struct SeihoTabViewIcon: View {
    
    let width, height: CGFloat
    let systemIconName, tabName: String
    @StateObject var viewRouter: SeihoTabViewRouter
    let assignedPage: Page
    
    var body: some View {
        VStack {
            Image(systemName: systemIconName)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: width / 5, height: height / 28)
                .padding(.top, 10)
            Text(tabName)
                .font(.footnote)
        }.padding(.horizontal, -4)
            .onTapGesture {
                viewRouter.currentPage = assignedPage
            }
            .foregroundColor(viewRouter.currentPage == assignedPage ? Color(.purple) : Color(.gray))
    }
}

struct SeihoTabViewPreviews: PreviewProvider {
    
    static var previews: some View {
        
        let router = SeihoTabViewRouter()
        
        Group {
            SeihoTabView(viewRouter: router)
        }
    }
}


