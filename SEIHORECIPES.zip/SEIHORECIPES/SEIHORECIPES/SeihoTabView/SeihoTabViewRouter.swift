//
//  SeihoTabViewRouter.swift
//  Seiho
//
//  Created by Leon Lux on 14.06.22.
//

import Foundation

enum Page {
    case recipes
    case liked
    case search
    case list
}

class SeihoTabViewRouter: ObservableObject {
    @Published var currentPage: Page = .recipes
}
